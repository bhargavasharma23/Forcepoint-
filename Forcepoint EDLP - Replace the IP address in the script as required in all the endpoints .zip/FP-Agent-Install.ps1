<#
.SYNOPSIS
    SentinelOne-optimized PowerShell script to install or override Forcepoint Agent

.DESCRIPTION
    Automates installation or reinstallation of the Forcepoint Agent
    with anti-tampering control, logging, and SentinelOne compatibility.

.AUTHOR
    Bhargava Sharma J
    Forcepoint Certified DLP System Engineer
    Foresight Software Solutions Pvt Ltd
    Contact: +91 91102 62738
    Email: bhargava.sj@foresightho.com

.COPYRIGHT
    (c) 2025 Bhargava Sharma J. All rights reserved.

.LICENSE
    Licensed under the MIT License.
#>

# =============================
# Initialize Log Function
# =============================
$LogPath = "C:\Temp\FP-Agent-Install.log"
function Log {
    param([string]$msg)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogPath -Value "$timestamp - $msg"
}

Log "=== Starting Forcepoint Agent installation script ==="

# =============================
# Variables
# =============================
$SensorURL = 'http://139.99.18.49:8443/Test/FORCEPOINT-ONE-ENDPOINT-x64.exe'
$SensorLocal = 'C:\Temp\FORCEPOINT-ONE-ENDPOINT-x64.exe'

# =============================
# Function: Enable/Disable Anti-Tampering
# =============================
function Set-AntiTampering {
    param (
        [Parameter(Mandatory = $true)][bool]$Disable,
        [string]$WebsensePath = "C:\Program Files\Websense\Websense endpoint",
        [string]$Password = "AVNc2UJ#8XJwk*"
    )

    $action = if ($Disable) { "Disabling" } else { "Re-enabling" }
    $value  = if ($Disable) { "true" } else { "false" }

    Log "$action anti-tampering..."

    $wdeutilPath = Join-Path $WebsensePath "wdeutil.exe"

    if (Test-Path $wdeutilPath) {
        & $wdeutilPath -set disableantitampering=$value -password $Password
        Log "Anti-tampering set to $value"
    } else {
        Log "wdeutil.exe not found at: $wdeutilPath"
    }
}

# =============================
# Ensure TEMP folder exists
# =============================
if (!(Test-Path -Path 'C:\Temp' -ErrorAction SilentlyContinue)) {
    Log "C:\Temp folder not found. Creating..."
    New-Item -ItemType Directory -Path 'C:\Temp' -Force | Out-Null
    Log "Created C:\Temp"
}

# =============================
# Disable Anti-Tampering before Install
# =============================
Set-AntiTampering -Disable $true

# =============================
# Download the Forcepoint Agent
# =============================
try {
    Log "Downloading Forcepoint Agent from $SensorURL..."
    Invoke-WebRequest -Uri $SensorURL -OutFile $SensorLocal
    Log "Download completed successfully."
} catch {
    Log "Download failed: $_"
    exit 1
}

# =============================
# Detect Existing Agent
# =============================
$existingAgent = Get-Service -Name 'Fppsvc' -ErrorAction SilentlyContinue
if ($null -ne $existingAgent) {
    Log "Forcepoint Agent is already installed. Proceeding with override..."
} else {
    Log "No existing Forcepoint Agent found. Proceeding with fresh install..."
}

# =============================
# Run the Installer
# =============================
Log "Running Forcepoint Agent installer (silent mode)..."
$install = Start-Process -FilePath $SensorLocal -ArgumentList "/v`"/qn /norestart`"" -Wait -PassThru

if ($install.ExitCode -eq 0 -or $install.ExitCode -eq 3010) {
    Log "Installation completed successfully. Exit Code: $($install.ExitCode)"
} else {
    Log "Installer exited with code $($install.ExitCode). Check installer logs."
    exit 2
}

# =============================
# Re-enable Anti-Tampering
# =============================
Set-AntiTampering -Disable $false

Log "=== Forcepoint Agent installation script completed ==="
