# Forcepoint Agent Installer Script

This repository contains a **SentinelOne-optimized PowerShell script** that automates the installation or reinstallation of the **Forcepoint One Endpoint Agent**.  
The script is designed to be secure, resilient, and deployment-ready with the following features:

- 📜 Centralized Logging → Outputs detailed logs with timestamps to `C:\Temp\FP-Agent-Install.log`.  
- 🔒 Anti-Tampering Management → Automatically disables anti-tampering before installation and re-enables it afterward.  
- 📦 Silent Installation → Executes the Forcepoint installer with `/qn /norestart` for seamless deployment.  
- 🔄 Override Mode → Detects existing Forcepoint Agent and reinstalls/updates if required.  
- 🌐 Reliable Download → Fetches the installer package from a configured URL, with error handling.  
- 🛡 SentinelOne Compatibility → Optimized for remote execution via the SentinelOne console.  
- ✅ Service Validation → Verifies if the Forcepoint Agent service (`Fppsvc`) is running post-install.  

## Author
**Bhargava Sharma J**  
Forcepoint Certified DLP System Engineer  
Foresight Software Solutions Pvt Ltd  
📧 bhargava.sj@foresightho.com | 📞 +91 91102 62738  

## License
This project is licensed under the MIT License – see the [LICENSE](LICENSE) file for details.
